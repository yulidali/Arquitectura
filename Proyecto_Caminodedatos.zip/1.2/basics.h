#ifndef BASICS_H
#define BASICS_H

enum opcodes {STALL, LOAD, WRITE, ADD, SUB,DIV,MULT, LESS, BRANCH};

#endif
